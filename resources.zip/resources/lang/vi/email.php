<?php
    return [
        'hello' => 'Xin chào!',
        'notifition' => 'Bạn vừa đặt hàng tại của hàng LD store của chúng, vui lòng nhấn nút bên dưới để xác thực đơn hàng.',
        'confirm' => 'Xác nhận mua hàng',
        'regards' => 'Trân trọng',
        'thank' => 'Cảm ơn bạn đã đặt hàng tại LD store!',
    ];
