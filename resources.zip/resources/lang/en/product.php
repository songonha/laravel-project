<?php
    return [
        'management' => 'Management product',
        'category' => 'Category',
        'name' => 'Name',
        'slug' => 'Slug',
        'description' => 'Description',
        'quantity' => 'Quantity',
        'price' => 'Price',
        'images' => 'Images',
        'chose_file' => 'Chose file images',
    ];