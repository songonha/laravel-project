<?php
    return [
        'hello' => 'Hello!',
        'notifition' => 'You have just placed an order at our LD store, please click the button below to confirm your order.',
        'confirm' => 'Purchase confirmation',
        'regards' => 'Regards',
        'thank' => 'Thank you for ordering at LD store.',
    ];